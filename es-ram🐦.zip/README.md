## perhatian ini hanya berapa android yg suport atau versi magisk

## module ini versi beta

#bisa meningkatkan penforma game/batre

